import java.util.Scanner;

public class Assignment2DIsplayDays {

	public static void main(String[] args) {
		System.out.print("Enter the No.of given days: ");
		try(Scanner I = new Scanner(System.in)){
			int givenDays = I.nextInt();
			int years = (givenDays/365);
			int remainDays = givenDays % 365;
			int months = 0; // initialised it as zero and why (read the below comments)
			// we have calculated remainDays value above and it's value will be in between 0 and 365.
			// we know January month has 31 days and if remainDays value is in between 0 and 31, 
			// months will become 0 and remainDays can be taken directly as days.
			// But if remainDays value is in between 31 and 365 we need to write 11 conditions for 11 months from February to December
			if (remainDays>=31 && remainDays <59 ) {months = 1; remainDays = remainDays - 31;} //January is over and February has 28 days
			if (remainDays>=59 && remainDays <90 ) {months = 2; remainDays = remainDays - 59;} //February is over and March has 31 days
			if (remainDays>=90 && remainDays <120)	{months = 3; remainDays = remainDays - 90;} //March is over and April has 30 days
			if (remainDays>=120 && remainDays <151) {months = 4; remainDays = remainDays - 120;} //April is over and May has 31 days
			if (remainDays>=151 && remainDays <181) {months = 5; remainDays = remainDays - 151;} //May is over and June has 30 days
			if (remainDays>=181 && remainDays <212) {months = 6; remainDays = remainDays - 181;} //June is over and July has 31 days
			if (remainDays>=212 && remainDays <243) {months = 7; remainDays = remainDays - 212;} //July is over and August has 31 days
			if (remainDays>=243 && remainDays <273) {months = 8; remainDays = remainDays - 243;} //August is over and September has 30 days
			if (remainDays>=273 && remainDays <304) {months = 9; remainDays = remainDays - 273;} //September is over and October has 31 days
			if (remainDays>=304 && remainDays <334) {months = 10; remainDays = remainDays - 304;} //October is over and November has 30 days
			if (remainDays>=334 && remainDays <365) {months = 11; remainDays = remainDays - 334;} //November is over and December has 31 days
			System.out.println("In " + givenDays +" days there will be " + years + " years " 
										+ months + " months and " + remainDays + " days, assuming given days starts from January 1st");
			
		}

	}

}