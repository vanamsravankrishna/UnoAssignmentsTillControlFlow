import java.util.Scanner;

public class Assignment8SalaryInHand {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the Monthly Salary: ");
			double salary = I.nextDouble();
			System.out.println("Enter the Annual Investment: ");
			double investment = I.nextDouble();
			double annualSalary = salary*12;
			double nonTaxInvestment = Math.min(100000,investment); //50,000
			double tax=0;
			double taxableIncome = Math.max(0,(annualSalary - nonTaxInvestment)); // 7,20,000 - 50,000
			if(taxableIncome>250000) {//6,70,000 execute
				tax+=250000*0.00;
				taxableIncome = taxableIncome - 250000; // 6,70,000 - 2,50,000 = 4,20,000
				if(taxableIncome>250000) { // 4,20,000 execute
					tax+=250000*0.05; // 12,500
					taxableIncome -= 250000; // 4,20,000 - 2,50,000 = 1,70,000
					if(taxableIncome>500000) {// not execute
						tax += 500000*0.20;
						taxableIncome -= 500000;
						tax += taxableIncome*0.30;
						}
					else {tax += taxableIncome*0.20;}// execute 1,70,000*20 = 3,400
					}
				else {tax += taxableIncome*0.05;} // no execute
				}
			else {tax += taxableIncome*0.00;}// not execute
			taxableIncome = Math.max(0,(annualSalary - nonTaxInvestment));
			double taxPerMonth = tax/12;
			double salaryInHand = salary - taxPerMonth;
			System.out.printf("Annual Income = %.2f%nTaxable Income = %.2f%nTax Payable(per year) = "
					+ "%.2f%nSalary in hand(per month) = %.2f",
						annualSalary,taxableIncome, tax, salaryInHand);
		}	
	} 
}
