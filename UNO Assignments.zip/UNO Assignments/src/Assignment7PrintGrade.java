import java.util.Scanner;

public class Assignment7PrintGrade {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the Marks: ");
			double marks = I.nextDouble();
			char grade = 
					(marks>=90 && marks<=100)? 'A':
						(marks>=75 && marks<90)? 'B':
							(marks>=60 && marks<75)? 'C':'F';
			System.out.println(grade);
		}
	}
}