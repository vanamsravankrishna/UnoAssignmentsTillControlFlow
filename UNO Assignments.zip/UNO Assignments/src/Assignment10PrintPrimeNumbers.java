import java.util.Scanner;

public class Assignment10PrintPrimeNumbers {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the given input: ");
			String Input1 = I.next();
			String Input2 = I.next();
			String input1Lower = Input1.toLowerCase();
			String input2Lower = Input2.toLowerCase();
				int firstInteger, secondInteger;
				int flag1, flag2;
				if(input1Lower.indexOf('e')!=-1) {
					firstInteger = Integer.parseInt(input1Lower.substring(0,input1Lower.indexOf('e')));
					flag1 =1;
					// this is excluded
				}
				else if(input1Lower.indexOf('i')!=-1){
					firstInteger = Integer.parseInt(input1Lower.substring(0,input1Lower.indexOf('i')));
					flag1 = 0;
					//this is included
				}
				else {
					firstInteger = Integer.parseInt(input1Lower);
					flag1 = 0;
					//this is included
				}
				
				if(input2Lower.indexOf('e')!=-1) {
					secondInteger = Integer.parseInt(input2Lower.substring(0,input2Lower.indexOf('e')));
					flag2 = 1;
					// this is excluded
				}
				else if(input2Lower.indexOf('i')!=-1){
					flag2 =0;
					secondInteger = Integer.parseInt(input2Lower.substring(0,input2Lower.indexOf('i')));
					//this included
				}
				else {
					secondInteger = Integer.parseInt(input2Lower);
					flag2 = 0;
					//this is included
					}
					firstInteger = Math.min(firstInteger,secondInteger);
					secondInteger = Math.max(firstInteger,secondInteger);
				
// 4 cases
// 1)both are included 2)both of excluded 
// 3)first excluded, second included 4)first included

				if(flag1==0 && flag2==0){
					for(int i=firstInteger; i<=secondInteger; i++) {
						int j,m=0,flag=0;   
						  m=i/2;      
						  if(i==0||i==1){        
						  }
						  else{  
						   for(j=2;j<=m;j++){      
						    if(i%j==0){            
						     flag=1;      
						     break;      
						    }      
						   }      
						   if(flag==0)  { System.out.print(i+ " "); }  
						  }//end of else
						
					}
				}
				else if(flag1!=0 && flag2==0){
					for(int i=firstInteger+1; i<=secondInteger; i++) {
						int j,m=0,flag=0;   
						  m=i/2;      
						  if(i==0||i==1){        
						  }
						  else{  
						   for(j=2;j<=m;j++){      
						    if(i%j==0){            
						     flag=1;      
						     break;      
						    }      
						   }      
						   if(flag==0)  { System.out.print(i+ " "); }  
						  }//end of else
						
					}
					
				}
				else if(flag1==0 && flag2!=0){
					for(int i=firstInteger; i<secondInteger; i++) {
						int j,m=0,flag=0;   
						  m=i/2;      
						  if(i==0||i==1){        
						  }
						  else{  
						   for(j=2;j<=m;j++){      
						    if(i%j==0){            
						     flag=1;      
						     break;      
						    }      
						   }      
						   if(flag==0)  { System.out.print(i+ " "); }  
						  }//end of else
						
					}
					
				}
				else {
					for(int i=firstInteger+1; i<secondInteger; i++) {
						int j,m=0,flag=0;   
						  m=i/2;      
						  if(i==0||i==1){        
						  }
						  else{  
						   for(j=2;j<=m;j++){      
						    if(i%j==0){            
						     flag=1;      
						     break;      
						    }      
						   }      
						   if(flag==0)  { System.out.print(i+ " "); }  
						  }//end of else
						
					}
				}
		}
	}
}


