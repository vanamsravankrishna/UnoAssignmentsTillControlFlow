import java.util.Scanner;
public class Assignment4PerimeterArea {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the length of rectangle: ");
			double	length = I.nextDouble();
			System.out.println("Enter the breadth of rectangle: ");
			double breadth = I.nextDouble();
			if (length != 0 && breadth != 0) {
				double area = length * breadth;
				double perimeter = 2 * (length + breadth);
				System.out.println("Area = " + area);
				System.out.println("Perimeter = " + perimeter);
				if (area > perimeter) {
					System.out.println("Area is greater than Perimeter");
					}
				else if (area < perimeter) {
					System.out.println("Perimeter is greater than Area");
					}
				else {
					System.out.println("Area is equal to perimeter");
					}
				}
			else {
				System.out.println("This is not a valid rectangle");
				}
			}
		}
	}