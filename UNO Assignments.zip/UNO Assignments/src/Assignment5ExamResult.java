import java.util.Scanner;

public class Assignment5ExamResult {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the Marks in SubjectA: ");
			double	marksInA = I.nextDouble();
			System.out.println("Enter the Marks in SubjectB: ");
			double marksInB = I.nextDouble();
			if((marksInA>= 55 && marksInB >= 45) || (marksInA<= 55 && marksInA>=45 && marksInB >= 55)) {
				System.out.println("The student has Passed");
				}
			else if(marksInA>= 65 && marksInB<=45) {
				System.out.println("The student has Failed, but can reappear in exam B");
			}
			else{
				System.out.println("The student has Failed");
			}
		}

	}

}
