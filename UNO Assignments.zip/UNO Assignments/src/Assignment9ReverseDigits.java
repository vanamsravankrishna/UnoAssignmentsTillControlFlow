import java.util.Scanner;
public class Assignment9ReverseDigits {
	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the given number: ");
			int number = I.nextInt();
			int reverse = 0;
			int temp=number;
			while(temp!=0) {
				reverse = (reverse*10)+ (temp % 10);
				temp = temp/10;
			}
			System.out.println("the reverse number of given number is "+ reverse);
		}
//		try(Scanner I = new Scanner(System.in)){
//			System.out.println("Enter the given number: ");
//			String number = I.next();
//			String reverse ="";
//			for(int i = number.length(); i>=1; i--) {
//				reverse = reverse + number.charAt(i-1);
//			}
//			System.out.println("the reverse number of given number is "+ reverse);
//		}
	}
}
