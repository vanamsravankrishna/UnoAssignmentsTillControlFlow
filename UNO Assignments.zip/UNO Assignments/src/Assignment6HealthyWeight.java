import java.util.Scanner;
import java.lang.Math;

public class Assignment6HealthyWeight {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the gender: ");
			String gender = I.next();
			System.out.println("Enter the weight in kgs: ");
			double weightInKgs = I.nextDouble();
			System.out.println("Enter the height in inches: ");
			double heightInInches = I.nextDouble();
			double heightInMeters = heightInInches * 0.0254;
			double BMI = weightInKgs/(heightInMeters*heightInMeters);
			String status = null;
			if(BMI<18.5) {
				status = "Underweight";
			}
			else if(BMI>=18.5 && BMI<25) {
				status = "Normal";
			}
			else if(BMI>=25 && BMI<30) {
				status = "Overweight";
			}
			else {
				status = "Obese";
			}
			double targetWeight = 0;
			if (gender.equals("male") || gender.equals("Male")) {
				targetWeight = 50 + (2.3 * Math.max(0,(heightInInches - 60)));
			}
			else {
				targetWeight = 45.5 + (2.3 * Math.max(0,(heightInInches - 60)));
			}
			String recommendation = null;
			double diff = 0;// this variable is to calculate the difference in current and target weights.
			if(weightInKgs > targetWeight) {
				recommendation = "You must loose";
				diff = weightInKgs - targetWeight;
			}
			else if(weightInKgs < targetWeight) {
				recommendation = "You must gain";
				diff = targetWeight - weightInKgs;
			}
			else {
				recommendation = "you are already fit. you gain or loose";
				diff = 0;
			}
			System.out.printf("Current weight = %.1f kgs%nBMI = %.2f%nStatus = %s%nTarget Weight = %.1f "
					+ "kgs%n%s %.1f kgs to get fit.",weightInKgs, BMI, status,targetWeight, recommendation, diff);
		}

	}

}
