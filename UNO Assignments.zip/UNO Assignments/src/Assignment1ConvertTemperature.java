import java.util.Scanner;
import java.lang.Math;
public class Assignment1ConvertTemperature {

	public static void main(String[] args) {
		System.out.print("Enter the given temperature in farenheit: ");
		try(Scanner I = new Scanner(System.in)){
			double givenTemperature = I.nextDouble();
			System.out.println("given temperature in celsius = "+ Math.round(((givenTemperature -32)*5.0)/9));
		}
	}

}
