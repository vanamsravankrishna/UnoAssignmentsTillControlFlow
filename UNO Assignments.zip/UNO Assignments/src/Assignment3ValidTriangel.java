import java.util.Scanner;
public class Assignment3ValidTriangel {

	public static void main(String[] args) {
		System.out.println("Enter the Angles of Triangle: ");
		try(Scanner I = new Scanner(System.in)){
			double	angleA = I.nextDouble();
			double angleB = I.nextDouble();
			double angleC = I.nextDouble();
			if(angleA + angleB + angleC == 180) {
				System.out.println("The Triangle is valid");
			}
			else {
				System.out.println("The Triangle is not valid");
				
			}
		}

	}

}
