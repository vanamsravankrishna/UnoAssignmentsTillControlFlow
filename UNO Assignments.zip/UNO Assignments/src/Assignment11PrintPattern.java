import java.util.Scanner;

public class Assignment11PrintPattern {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the given input: ");
			int n = I.nextInt();
			for(int i=1;i<=n;i++) {
				for(int j=1; j<=i;j++) {
					System.out.print('*');
				}
				System.out.println();
			}
			for(int i=1;i<=n;i++) {
				for(int j=11; j<=11+n-i;j++) {
					System.out.print(j+" ");
				}
				System.out.println();
			}
			for(int i=1; i<= n; i++) {
				char a = 'A';
				for(int l=1; l<i; l++) {
					a++;
				}		
				for(int k=1; k<=n-i; k++) {
					System.out.print(" ");
					}
				for(char j= a; j>='A'; j--) {
					System.out.print(j);
					}
				System.out.println();
			}
		}
	}

}
