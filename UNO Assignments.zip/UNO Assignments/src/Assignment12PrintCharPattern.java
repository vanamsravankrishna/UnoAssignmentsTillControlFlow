import java.util.Scanner;

public class Assignment12PrintCharPattern {

	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the given input: ");
			String n = I.next();
			char c = n.charAt(0);
			String s= "A";
			for(char i = 'B'; i <= c; i++) {
				s = s + i;
			}
			c--;
			for(char i = c--; i >= 'A'; i--) {
				s = s + i;
			}
			System.out.println(s);
			c= n.charAt(0);
			for(char i=c; i>'A'; i--) {
				s = s.replace(i,' ');
				System.out.println(s);
			}
		}
	}
}
