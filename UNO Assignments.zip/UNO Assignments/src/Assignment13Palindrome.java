import java.util.Scanner;
public class Assignment13Palindrome {
	public static void main(String[] args) {
		try(Scanner I = new Scanner(System.in)){
			System.out.println("Enter the Required input: ");
			String s = I.next();
			String reverse ="";
			for(int i = s.length(); i>=1; i--) {
				reverse = reverse + s.charAt(i-1);
			}
			if(s.equals(reverse)) {
				System.out.println("Given input is a Palindrome");
			}
			else {
				System.out.println("Given input in not a Palindrome");
			}
		}
	}
}
